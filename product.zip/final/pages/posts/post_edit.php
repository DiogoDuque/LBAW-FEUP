<?php

include_once("../../config/init.php");
include_once ($BASE_DIR."database/posts.php");
include_once ($BASE_DIR."database/versions.php");
include_once ($BASE_DIR."database/members.php");

if (!isset($_GET['id']))
    die('Missing post ID.');

if (!isset($_SESSION['username']))
    die('Member not authenticated.');

$smarty->display("common/header.tpl");

$post = getPost($_GET["id"]);
$currentVersion = getLatestPostVersion($_GET["id"]);
$member_id = intval(getMemberByUsername($_SESSION["username"])["id"]);

?>

<div class="container">
    <h1 class="text-center">Edit Post</h1>

    <!--TODO: Put text to a PHP POST.-->
    <form action="<?=$BASE_URL?>actions/post/post_apply_edit.php" method="post">

        <input type="hidden" name="post_id" value="<?=$_GET["id"]?>">
        <input type="hidden" name="member_id" value="<?=$member_id?>">

        <div class="new-post">

            <textarea id="summernote" class="formgroup"  name="edited_text">
                    <?=htmlspecialchars($currentVersion["text"], ENT_QUOTES, 'UTF-8')?>
            </textarea>

            <script>
                $(document).ready(function () {
                    var summernote = $('#summernote');
                    summernote.summernote({
                        height: '20rem',
                        minHeight: '20rem',
                        toolbar: [
                            // [groupName, [list of button]]
                            ['style', ['bold', 'italic', 'underline', 'clear']],
                            ['font', ['strikethrough', 'superscript', 'subscript']],
                            ['para', ['ul', 'ol']],
                            ['insert', ['link', 'table']],
                            ['misc', ['undo', 'redo', 'help']]
                        ]
                    });
                });
            </script>

        </div>

        <button type="submit" onclick="sendEditedText()" class="btn btn-success">Apply</button>
    </form>
</div>

<script>
    function sendEditedText(){
        document.forms["sampleForm"].submit();
    }

    function resetEditedText(){
        var uneditedText = <?= json_encode($currentVersion["text"], JSON_HEX_TAG);?>;
        $('#summernote').summernote('code', uneditedText);
    }
</script>

<?php $smarty->display("common/footer.tpl"); ?>
