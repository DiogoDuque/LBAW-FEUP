<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:56:27
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/lists/question_list_item.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1487325866592c990bb2ce06-88249781%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4722b0445613a0d0474cb3954b1f0a272fc5db11' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/lists/question_list_item.tpl',
      1 => 1496077850,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1487325866592c990bb2ce06-88249781',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'BASE_URL' => 0,
    'question' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c990bb99708_42252921',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c990bb99708_42252921')) {function content_592c990bb99708_42252921($_smarty_tpl) {?><div class="row">

    <div class="col-sm-10 pre">
        <h4><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/posts/question.php?id=<?php echo $_smarty_tpl->tpl_vars['question']->value['id'];?>
" class="home-question-title"><?php echo $_smarty_tpl->tpl_vars['question']->value['title'];?>
</a><br>
            <small>asked <?php echo $_smarty_tpl->tpl_vars['question']->value['date'];?>
 ago by <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/profile/view_profile.php?id=<?php echo $_smarty_tpl->tpl_vars['question']->value['author_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['question']->value['author'];?>
</a> in <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/home.php?category=<?php echo $_smarty_tpl->tpl_vars['question']->value['category_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['question']->value['category'];?>
</a></small>
        </h4>
    </div>



    <div class="points col-sm-1 col-xs-6">
        <h4 class="text-center">
            <span class="points"><?php echo $_smarty_tpl->tpl_vars['question']->value['score'];?>
</span>
            <br>
            <small>point<?php if ($_smarty_tpl->tpl_vars['question']->value['score']!=1) {?>s<?php }?></small>
        </h4>
    </div>


    <div class="answers col-sm-1 col-xs-6">
        <h4 class="text-center">
            <span class="answers">
                <?php echo $_smarty_tpl->tpl_vars['question']->value['answer_count'];?>

                <small><span class="glyphicon glyphicon-comment"></span></small>
            </span>
            <br>
            <small>
                answer<?php if ($_smarty_tpl->tpl_vars['question']->value['answer_count']!=1) {?>s<?php }?>
            </small>
        </h4>
    </div>
</div><?php }} ?>
