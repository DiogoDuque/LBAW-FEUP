<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:19:14
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/common/info.tpl" */ ?>
<?php /*%%SmartyHeaderCode:542193745592c9052e4a4f2-15451172%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '500d0a570f57f3a6798f9cb6a723ecdf13156a41' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/common/info.tpl',
      1 => 1493024227,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '542193745592c9052e4a4f2-15451172',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'redirect_destiny' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c90530968c4_94275012',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c90530968c4_94275012')) {function content_592c90530968c4_94275012($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('common/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>




<div class="alert alert-info">
    <strong>Info!</strong> <?php echo $_SESSION['error_messages'];?>

    <br>
    Redirecting...
</div>

If you are not redirected, click <a href="<?php echo $_smarty_tpl->tpl_vars['redirect_destiny']->value;?>
">here</a>


<?php echo $_smarty_tpl->getSubTemplate ('common/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
