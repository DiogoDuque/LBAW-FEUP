<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 19:32:40
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/common/pagination.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2132455032592c6948d33356-79708141%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3dc858306dc8daa5023b5a4a905824f66b5ce075' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/common/pagination.tpl',
      1 => 1496077850,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2132455032592c6948d33356-79708141',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'url' => 0,
    'page' => 0,
    'results' => 0,
    'limit' => 0,
    'var' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c6948d98be2_77255616',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c6948d98be2_77255616')) {function content_592c6948d98be2_77255616($_smarty_tpl) {?><ul class="pagination pagination-lg">
    <li><a id="previousPage" href="?<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
&page=<?php echo max($_smarty_tpl->tpl_vars['page']->value-1,1);?>
" class="btn">«</a></li>
        <?php $_smarty_tpl->tpl_vars['var'] = new Smarty_Variable;$_smarty_tpl->tpl_vars['var']->step = 1;$_smarty_tpl->tpl_vars['var']->total = (int) ceil(($_smarty_tpl->tpl_vars['var']->step > 0 ? $_smarty_tpl->tpl_vars['results']->value['0']['count']/$_smarty_tpl->tpl_vars['limit']->value+1 - (1) : 1-($_smarty_tpl->tpl_vars['results']->value['0']['count']/$_smarty_tpl->tpl_vars['limit']->value)+1)/abs($_smarty_tpl->tpl_vars['var']->step));
if ($_smarty_tpl->tpl_vars['var']->total > 0) {
for ($_smarty_tpl->tpl_vars['var']->value = 1, $_smarty_tpl->tpl_vars['var']->iteration = 1;$_smarty_tpl->tpl_vars['var']->iteration <= $_smarty_tpl->tpl_vars['var']->total;$_smarty_tpl->tpl_vars['var']->value += $_smarty_tpl->tpl_vars['var']->step, $_smarty_tpl->tpl_vars['var']->iteration++) {
$_smarty_tpl->tpl_vars['var']->first = $_smarty_tpl->tpl_vars['var']->iteration == 1;$_smarty_tpl->tpl_vars['var']->last = $_smarty_tpl->tpl_vars['var']->iteration == $_smarty_tpl->tpl_vars['var']->total;?>
            <li><a id="currentPage" href="?<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
&page=<?php echo $_smarty_tpl->tpl_vars['var']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['var']->value;?>
</a></li>
        <?php }} ?>
    <li><a id="nextPage" href="?<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
&page=<?php echo min($_smarty_tpl->tpl_vars['page']->value+1,ceil($_smarty_tpl->tpl_vars['results']->value['0']['count']/$_smarty_tpl->tpl_vars['limit']->value));?>
" class="btn">»</a></li>
</ul>

<script>
    var numberOfPages = <?php echo ceil(count($_smarty_tpl->tpl_vars['results']->value['0'])/$_smarty_tpl->tpl_vars['limit']->value);?>
;
    var currentPage = parseInt($("#currentPage").text());


    $(function () {

        if (numberOfPages === currentPage) {
            $("#nextPage").addClass("disabled");
        }

        {
            if (currentPage === 1)
                $("#previousPage").addClass("disabled");
        }
    });
</script><?php }} ?>
