<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:55:34
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/admin/categories_menu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1304057318592c98d6b4b8f4-86502422%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b2a7172c3801552b7f09868f5b7ad3438dfca7e2' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/admin/categories_menu.tpl',
      1 => 1496094327,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1304057318592c98d6b4b8f4-86502422',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'categories' => 0,
    'category' => 0,
    'BASE_URL' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c98d6b5a1e7_73787524',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c98d6b5a1e7_73787524')) {function content_592c98d6b5a1e7_73787524($_smarty_tpl) {?><div class="col-md-9">
    <div class="panel panel-default">

        <div class="panel-heading">
            <div class="panel-title">
                <i class="glyphicon glyphicon-wrench pull-right"></i>
                <h4>Categories Menu</h4>
            </div>
        </div>

        <div class="panel-body">
            <form id="add_category" action="../../actions/admin/create_category.php" method="post"
                  enctype="multipart/form-data" class="form form-vertical">
                <div class="control-group">
                    <label>Add Category</label>
                    <div class="controls">
                        <input id="new_category_name" type="text" class="form-control" placeholder="Enter Name"
                               name="id"
                               required>
                    </div>
                </div>
                <div class="control-group">
                    <label></label>
                    <div class="controls">
                        <button type="submit" class="btn btn-primary">
                            Add
                        </button>
                    </div>
                </div>
            </form>

        </div>

        <div class="panel-body">
            <form id="remove_category" action="../../actions/admin/remove_category.php" method="post"
                  enctype="multipart/form-data" class="form form-vertical">
                <div class="control-group">
                    <label>Remove Category</label>
                    <div class="controls">
                        <select id="remove_category_name" name="name" class="form-control" required>
                            <option value="" selected>Select a category.</option>
                            <?php  $_smarty_tpl->tpl_vars['category'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['category']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['categories']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['category']->key => $_smarty_tpl->tpl_vars['category']->value) {
$_smarty_tpl->tpl_vars['category']->_loop = true;
?>
                                <option value="<?php echo $_smarty_tpl->tpl_vars['category']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['category']->value['name'];?>
</option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="control-group">
                    <label></label>
                    <div class="controls">
                        <button type="submit" class="btn btn-danger">
                            Remove
                        </button>
                    </div>
                </div>
            </form>

        </div>
    </div>
</div>
<script type='text/javascript' src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
lib/js/admin_categories_menu.js"></script><?php }} ?>
