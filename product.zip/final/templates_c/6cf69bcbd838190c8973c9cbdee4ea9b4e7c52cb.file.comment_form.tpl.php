<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:56:33
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/comments/comment_form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1232885868592c99118bbf44-25133580%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6cf69bcbd838190c8973c9cbdee4ea9b4e7c52cb' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/comments/comment_form.tpl',
      1 => 1496094327,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1232885868592c99118bbf44-25133580',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'BASE_URL' => 0,
    'post_id' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c99118c3092_45455376',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c99118c3092_45455376')) {function content_592c99118c3092_45455376($_smarty_tpl) {?><div class="comment col-md-11 col-md-offset-1 comment_add_form" style="display:none">
    <div class="widget-area no-padding blank">
        <div class="comment-box">
            <form action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/post/comment_add.php" class="comment_form" method="post"
                  enctype="multipart/form-data">
                <input type="hidden" name="post_id" value="<?php echo $_smarty_tpl->tpl_vars['post_id']->value;?>
">
                <textarea placeholder="Comment" name="text" required></textarea>
                <button type="submit" class="btn btn-success green">Apply</button>
            </form>
        </div>
    </div>
</div><?php }} ?>
