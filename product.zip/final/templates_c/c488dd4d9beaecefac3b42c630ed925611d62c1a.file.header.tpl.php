<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:56:33
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/common/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:224906508592c991154eed1-12944749%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c488dd4d9beaecefac3b42c630ed925611d62c1a' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/common/header.tpl',
      1 => 1496094327,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '224906508592c991154eed1-12944749',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'BASE_URL' => 0,
    'categories' => 0,
    'category' => 0,
    'PERMISSIONS' => 0,
    'USERNAME' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c9911767f29_22610064',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c9911767f29_22610064')) {function content_592c9911767f29_22610064($_smarty_tpl) {?><!DOCTYPE html>
<html lang="en">
<head>
    <title>HoWhy</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta property="og:url"           content="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
" />
    <meta property="og:type"          content="website" />
    <meta property="og:title"         content="HoWhy" />
    <meta property="og:description"   content="The best place to ask your questions!" />
    <meta property="og:image"         content="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
resources/img/howhy-logo-with-text.svg" />

    <link rel="stylesheet" type="text/css" href= "<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href= "<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
lib/css/main.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.2/summernote.css" rel="stylesheet">
    <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.2/summernote.js"></script>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>

    <link rel="icon" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
resources/img/logo-64.ico">
</head>
<body>

    <div id="fb-root"></div>
    <script>(function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>

<nav class="navbar navbar-inverse">
    <div class="container-fluid">

        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <a class="logo pull-left navbar-header" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/home.php"><img src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
resources/img/howhy-logo-with-text.svg" height="30" alt="Homepage"></a>

        </div>

        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">

                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Categories <span
                            class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <?php  $_smarty_tpl->tpl_vars['category'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['category']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['categories']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['category']->key => $_smarty_tpl->tpl_vars['category']->value) {
$_smarty_tpl->tpl_vars['category']->_loop = true;
?>
                            <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/home.php?category=<?php echo $_smarty_tpl->tpl_vars['category']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['category']->value['name'];?>
</a></li>
                        <?php } ?>
                    </ul>
                </li>

                <?php if ($_smarty_tpl->tpl_vars['PERMISSIONS']->value=="Administrator"||$_smarty_tpl->tpl_vars['PERMISSIONS']->value=="Moderator") {?>

                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/admin/reports.php">Control Panel</a></li>

                <?php }?>


            </ul>

            <form action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/posts/search.php#results" class="navbar-form navbar-right" role="search">
                <div class="form-group input-group">
                    <input type="text" class="form-control" placeholder="Search.." name="query">

                    <span class="input-group-btn">
                        <button type="submit" class="btn btn-default" data-toggle="tooltip" data-placement="bottom" title="Advanced search">
                            <span class="glyphicon glyphicon-search search-icon"></span>
                        </button>


                    </span>
                </div>
            </form>

            <?php if ((!isset($_smarty_tpl->tpl_vars['USERNAME']->value))) {?>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#" data-toggle="modal" data-target="#signUp-modal"><span
                            class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                    <li><a href="#" data-toggle="modal" data-target="#login-modal"><span
                            class="glyphicon glyphicon-log-in"></span> Login</a></li>
                </ul>
            <?php } else { ?>
                <ul class="nav navbar-nav navbar-right">
                    <li><button type="button" class="btn btn-primary vertical-align" onclick="location.href='<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/posts/question_add.php';">Ask a question</button></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/profile/view_profile.php"><span class="glyphicon glyphicon-user"></span> Hello, <?php echo $_smarty_tpl->tpl_vars['USERNAME']->value;?>
 </a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/auth/logout.php" data-toggle="modal"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
                </ul>
            <?php }?>


        </div>

    </div>
</nav>

<div class="modal fade" id="login-modal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4><span class="glyphicon glyphicon-lock"></span> Login</h4>
            </div>

            <div class="modal-body">
                <form action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/auth/login.php" method="post">
                    <div class="form-group">
                        <label for="username"><span class="glyphicon glyphicon-user"></span> Username</label>
                        <input name="username" type="text" class="form-control" id="username" placeholder="Enter Username" required>
                    </div>
                    <div class="form-group">
                        <label for="psw"><span class="glyphicon glyphicon-eye-open"></span> Password</label>
                        <input name="password" type="password" class="form-control" id="psw" placeholder="Enter password" required>
                    </div>
                    <div class="checkbox">
                        <label><input type="checkbox" value="" checked>Remember me</label>
                    </div>
                    <button type="submit" class="btn btn-success btn-block"><span
                            class="glyphicon glyphicon-off"></span> Login
                    </button>
                </form>
            </div>
            <div class="modal-footer">
                <p>Not a member? <a href="#">Sign Up</a></p>
                <p>Forgot <a href="#">Password?</a></p>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="signUp-modal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4><span class="glyphicon glyphicon-lock"></span>Sign Up</h4>
            </div>

            <div class="modal-body">
                <form action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/auth/signup.php" method="post">
                    <input type='hidden' name='posted' value='true'>

                    <div class="form-group">
                        <label for="username_signup"><span class="glyphicon glyphicon-user"></span> Username</label>
                        <input name="username" type="text" class="form-control" id="username_signup" placeholder="Enter username" autocomplete="off" required>
                    </div>
                    <div class="form-group">
                        <label for="email_signup"><span class="glyphicon glyphicon-envelope"></span> Email</label>
                        <input name="email" type="email" class="form-control" id="email_signup" placeholder="Enter email" autocomplete="off" required>
                    </div>
                    <div class="form-group">
                        <label for="psw_signup"><span class="glyphicon glyphicon-eye-open"></span> Password</label>
                        <input name="password" type="password" class="form-control" id="psw_signup" placeholder="Enter password" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_psw_signup"><span class="glyphicon glyphicon-eye-ope"></span> Confirm Password</label>
                        <input name="confirm_password" type="password" class="form-control" id="confirm_psw_signup" placeholder="Reenter password" required><span id='message'></span>
                    </div>
                    <button type="submit" class="btn btn-success btn-block" id="button_signup"><span
                            class="glyphicon glyphicon-registration-mark"></span> Sign Up
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
lib/js/signup_modal.js"></script>

<script>

    function showErrorMessage(message){
        $('#message').html(message).css('color', 'red');
            $('#button_signup').prop('disabled', true);
    }

    function validate(){
        var pattern = /[^\w\d]+/;

        var username = $('#username_signup').val();
        if(username.length<4 || username.length>20){
            showErrorMessage("Username must have between 4 and 20 characters.");
            return;
        }

        var usernameHasSymbols = pattern.test(username);
        if(usernameHasSymbols){
            showErrorMessage("Username can only contain characters and numbers.");
            return;
        }

        var email = $('#email_signup').val();
        var emailIsCorrect = /[\w\d]+@[\w\d]+/.test(email);
        console.log(emailIsCorrect);
        if(!emailIsCorrect){
            showErrorMessage("Email does not appear to be correct.");
            return;
        }

        var password = $('#psw_signup').val();
        if(password.length<4 || password.length>20){
            showErrorMessage("Password must have between 4 and 20 characters.");
            return;
        }

        var passwordHasSymbols = pattern.test(password);
        if(passwordHasSymbols){
            showErrorMessage("Password can only contain characters and numbers.");
            return;
        }

        var passwordConf = $('#confirm_psw_signup').val();
        if(password != passwordConf){
            showErrorMessage("Password is not matching.");
            return;
        }

        $('#message').html('');
        $('#button_signup').prop('disabled', false);
    }

    $('#button_signup').prop('disabled', true);

    $('#username_signup, #email_signup, #psw_signup, #confirm_psw_signup').on('keyup', function () {
        validate();
    });

</script>
<?php }} ?>
