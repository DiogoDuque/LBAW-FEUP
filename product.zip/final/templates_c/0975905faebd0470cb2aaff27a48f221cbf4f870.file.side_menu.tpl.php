<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:55:49
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/admin/side_menu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1078566939592c98e50a4178-97970270%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0975905faebd0470cb2aaff27a48f221cbf4f870' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/admin/side_menu.tpl',
      1 => 1496094534,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1078566939592c98e50a4178-97970270',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'BASE_URL' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c98e50d2364_52104022',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c98e50d2364_52104022')) {function content_592c98e50d2364_52104022($_smarty_tpl) {?><div class="col-md-3">
    <a class="title" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/admin/admin.php"><strong><i class="glyphicon glyphicon-dashboard"></i>My Dashboard</strong></a>

    <div class="panel-group" id="accordion">

        <a data-toggle="collapse" data-parent="#accordion" href="#collapseMembers">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                            <span class="glyphicon glyphicon-user">
                            </span>Members
                    </h4>
                </div>
            </div>
        </a>
        <div id="collapseMembers" class="panel-collapse collapse">
            <div class="panel-body">
                <table class="table">
                    <tr>
                        <td>
                            <span class="text-primary"></span><a
                                    href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/admin/view_members.php">View members</a>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <span class="text-primary"></span><a
                                    href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/admin/ban_members.php">Ban members</a>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <span class="text-primary"></span><a
                                    href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/admin/promote_members.php">Promote/Demote members</a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <a data-toggle="collapse" data-parent="#accordion" href="#collapseCategories">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                            <span class="glyphicon glyphicon-folder-close">
                            </span>Categories
                    </h4>
                </div>
            </div>
        </a>
        <div id="collapseCategories" class="panel-collapse collapse">
            <div class="panel-body">
                <table class="table">
                    <tr>
                        <td>
                            <span class="text-primary"></span><a
                                    href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/admin/manage_categories.php">Manage categories</a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <a data-toggle="collapse" data-parent="#accordion" href="#collapseReports">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                            <span class="glyphicon glyphicon-inbox">
                            </span>Reports
                    </h4>
                </div>
            </div>
        </a>
        <div id="collapseReports" class="panel-collapse collapse">
            <div class="panel-body">
                <table class="table">
                    <tr>
                        <td>
                            <span class="text-primary"></span><a
                                    href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/admin/reports.php">View reports</a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <a data-toggle="collapse" data-parent="#accordion" href="#collapseStats">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
                            <span class="glyphicon glyphicon-list-alt">
                            </span>Stats
                    </h4>
                </div>
            </div>
        </a>
        <div id="collapseStats" class="panel-collapse collapse">
            <div class="panel-body">
                <table class="table">
                    <tr>
                        <td>
                            <span class="text-primary"></span><a
                                    href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/admin/general_stats.php">View general stats</a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

</div>

<script>


</script>

<?php }} ?>
