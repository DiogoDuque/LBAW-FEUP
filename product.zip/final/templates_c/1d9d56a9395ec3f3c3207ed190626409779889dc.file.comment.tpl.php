<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:56:33
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/comments/comment.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1061785804592c9911939627-84324979%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1d9d56a9395ec3f3c3207ed190626409779889dc' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/comments/comment.tpl',
      1 => 1496077850,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1061785804592c9911939627-84324979',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'comment' => 0,
    'BASE_URL' => 0,
    'currentUser' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c9911964cc0_78116477',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c9911964cc0_78116477')) {function content_592c9911964cc0_78116477($_smarty_tpl) {?><div class="comment col-md-11 col-md-offset-1" data-comment-id="<?php echo $_smarty_tpl->tpl_vars['comment']->value['id'];?>
">
    <p class="comment_text"><?php echo $_smarty_tpl->tpl_vars['comment']->value['text'];?>
</p>
    <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/profile/view_profile.php?id=<?php echo $_smarty_tpl->tpl_vars['comment']->value['member_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['comment']->value['member']['username'];?>
</a>
    <ul class="actions pull-right">
        <?php if ($_smarty_tpl->tpl_vars['currentUser']->value['username']==$_smarty_tpl->tpl_vars['comment']->value['member']['username']||$_smarty_tpl->tpl_vars['currentUser']->value['privilege_level']=="Administrator"||$_smarty_tpl->tpl_vars['currentUser']->value['privilege_level']=="Moderator") {?>
            <li><a class="glyphicon glyphicon-pencil comment_edit_button" href="<?php echo $_smarty_tpl->tpl_vars['comment']->value['id'];?>
" data-toggle="tooltip" title="Edit"></a></li>
            <li><a class="glyphicon glyphicon-trash comment-delete"
               href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/post/comment_delete.php"
               data-toggle="tooltip" title="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
Remove"></a>
            </li>
        <?php }?>
    </ul>
</div><?php }} ?>
