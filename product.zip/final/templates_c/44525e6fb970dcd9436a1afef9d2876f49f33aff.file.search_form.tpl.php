<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 19:32:40
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/forms/search_form.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1101589475592c6948c1e1c0-78933392%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '44525e6fb970dcd9436a1afef9d2876f49f33aff' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/forms/search_form.tpl',
      1 => 1496077850,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1101589475592c6948c1e1c0-78933392',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'BASE_URL' => 0,
    'query' => 0,
    'search_titles' => 0,
    'search_descriptions' => 0,
    'search_answers' => 0,
    'orders' => 0,
    'order' => 0,
    'search_order' => 0,
    'categories' => 0,
    'category' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c6948c93587_67290325',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c6948c93587_67290325')) {function content_592c6948c93587_67290325($_smarty_tpl) {?><link rel="stylesheet" href= "<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
lib/css/search.css">

<!--Content-->
<div class="container">
    <h1 class="text-center">Advanced Search</h1>

    <form id="search_form">
        <div class="form-group">
            <label for="query">Search for:</label>
            <input id="query" type="text" class="form-control" name="query" value="<?php echo $_smarty_tpl->tpl_vars['query']->value;?>
">
        </div>

        <div class="container">
            <div class="row">

                <div class="col-sm-4">
                    <div class="checkbox">
                        <label><input type="checkbox" name="search_titles" value="1"
                                    <?php if ($_smarty_tpl->tpl_vars['search_titles']->value==1) {?> checked<?php }?>>
                            Search in Titles</label>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="checkbox">
                        <label><input type="checkbox" name="search_descriptions" value="1"
                                    <?php if ($_smarty_tpl->tpl_vars['search_descriptions']->value==1) {?> checked<?php }?>>
                            Search in Descriptions</label>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="checkbox">
                        <label><input type="checkbox"  name="search_answers" value="1"
                                    <?php if ($_smarty_tpl->tpl_vars['search_answers']->value==1) {?> checked<?php }?>>
                            Search in Answers</label>
                    </div>
                </div>

            </div>
        </div>

        <div class="form-group">
            <label for="search_order">Order by:</label>
            <select id="search_order" class="form-control" name="search_order">
                <?php  $_smarty_tpl->tpl_vars['value'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['value']->_loop = false;
 $_smarty_tpl->tpl_vars['order'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['orders']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['value']->key => $_smarty_tpl->tpl_vars['value']->value) {
$_smarty_tpl->tpl_vars['value']->_loop = true;
 $_smarty_tpl->tpl_vars['order']->value = $_smarty_tpl->tpl_vars['value']->key;
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['order']->value;?>
"
                            <?php if ($_smarty_tpl->tpl_vars['order']->value==$_smarty_tpl->tpl_vars['search_order']->value) {?> selected<?php }?>>
                    <?php echo $_smarty_tpl->tpl_vars['order']->value;?>
</option>
                <?php } ?>
            </select>
        </div>

        <h5>Filter by Category (<a class="categories" id="all_categories">Select All</a>|<a class="categories" id="no_categories">Unselect All</a>)</h5>

        <div class="container">
            <div class="row">

                <?php  $_smarty_tpl->tpl_vars['category'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['category']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['categories']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['category']->key => $_smarty_tpl->tpl_vars['category']->value) {
$_smarty_tpl->tpl_vars['category']->_loop = true;
?>
                    <div class="col-sm-3">
                        <div class="checkbox">
                            <label><input type="checkbox" class="category_checkbox" name="search_categories[]" value="<?php echo $_smarty_tpl->tpl_vars['category']->value['id'];?>
"
                                        <?php if ($_smarty_tpl->tpl_vars['category']->value['checked']==1) {?> checked<?php }?>>
                                <?php echo $_smarty_tpl->tpl_vars['category']->value['name'];?>
</label>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>

        <button type="submit" class="btn btn-success btn-block">Search</button>
        <button type="reset" class="btn btn-danger btn-block">Reset</button>
    </form>

    <script type='text/javascript' src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
lib/js/search_form.js"></script>
</div><?php }} ?>
