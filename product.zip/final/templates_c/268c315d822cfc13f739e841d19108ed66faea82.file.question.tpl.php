<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:56:33
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/posts/question.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1465210047592c9911773517-81612698%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '268c315d822cfc13f739e841d19108ed66faea82' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/posts/question.tpl',
      1 => 1496094327,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1465210047592c9911773517-81612698',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'BASE_URL' => 0,
    'question' => 0,
    'question_category' => 0,
    'question_post' => 0,
    'question_author' => 0,
    'question_version' => 0,
    'currentUser' => 0,
    'question_comments' => 0,
    'USERNAME' => 0,
    'question_answers' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c99118b8094_41009800',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c99118b8094_41009800')) {function content_592c99118b8094_41009800($_smarty_tpl) {?><link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
lib/css/question.css">



<div class="container">
    <?php if (!$_smarty_tpl->tpl_vars['question']->value['post_id']) {?>
        <?php echo $_smarty_tpl->getSubTemplate ('common/not_found.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    <?php } else { ?>
        <ol class="breadcrumb">
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/home.php">Home</a></li>
            <li> <?php echo $_smarty_tpl->tpl_vars['question_category']->value['name'];?>
 </li>
            <li class="active"><?php echo $_smarty_tpl->tpl_vars['question']->value['title'];?>
</li>
        </ol>

        <h2><?php echo $_smarty_tpl->tpl_vars['question']->value['title'];?>
</h2>
        <small class="pull-right">
            <?php echo $_smarty_tpl->tpl_vars['question_post']->value['up_votes'];?>

            <span class="glyphicon glyphicon-thumbs-up"></span>
            <?php echo $_smarty_tpl->tpl_vars['question_post']->value['down_votes'];?>

            <span class="glyphicon glyphicon-thumbs-down"></span>
        </small>

        <div class="question row">

            <div class="userInfo col-md-2">


                <div class="user">
                    <?php if ($_smarty_tpl->tpl_vars['question_author']->value['filename']) {?>
                        <img alt="User Pic" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
resources/uploads/<?php echo $_smarty_tpl->tpl_vars['question_author']->value['filename'];?>
" class="img-circle img-responsive"
                             width="100"
                             height="100">
                    <?php } else { ?>
                        <img alt="User Pic" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
resources/img/user.png" class="img-circle img-responsive"
                             width="100"
                             height="100">
                    <?php }?>
                    <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/profile/view_profile.php?id=<?php echo $_smarty_tpl->tpl_vars['question_author']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['question_author']->value['username'];?>
</a>
                </div>


                <ul class="score">
                    <li><span class="glyphicon glyphicon-thumbs-up" data-post_id="<?php echo $_smarty_tpl->tpl_vars['question']->value['post_id'];?>
"></span></li>
                    <li><p class="post_score"
                           data-post_id="<?php echo $_smarty_tpl->tpl_vars['question']->value['post_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['question_post']->value['up_votes']-$_smarty_tpl->tpl_vars['question_post']->value['down_votes'];?>
</p>
                    </li>
                    <li><span class="glyphicon glyphicon-thumbs-down" data-post_id="<?php echo $_smarty_tpl->tpl_vars['question']->value['post_id'];?>
"></span></li>
                </ul>

            </div>


            <div class="col-md-10">
                <p><?php echo $_smarty_tpl->tpl_vars['question_version']->value['text'];?>
</p>
                <ul class="actions pull-right">
                    <li><div class="fb-share-button" data-href="http://gnomo.fe.up.pt/~lbaw1623/LBAW-FEUP/final/pages/posts/question.php?id=<?php echo $_smarty_tpl->tpl_vars['question_author']->value['id'];?>
" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fgnomo.fe.up.pt%2F%7Elbaw1623%2FLBAW-FEUP%2Ffinal%2Fpages%2Fposts%2Fquestion.php%3Fid%3D&amp;src=sdkpreparse">Partilhar</a></div></li>
                    <?php if ($_smarty_tpl->tpl_vars['currentUser']->value) {?>
                        <li><a class="glyphicon glyphicon-comment comment_add_toogle" href="" data-toggle="tooltip" title="Comment"></a>                        </li>
                        <li><a class="glyphicon glyphicon-flag report_button" href="<?php echo $_smarty_tpl->tpl_vars['question']->value['post_id'];?>
" data-toggle="tooltip" title="Report"></a></li>
                        <?php if ($_smarty_tpl->tpl_vars['currentUser']->value['username']==$_smarty_tpl->tpl_vars['question_author']->value['username']||$_smarty_tpl->tpl_vars['currentUser']->value['privilege_level']=="Administrator"||$_smarty_tpl->tpl_vars['currentUser']->value['privilege_level']=="Moderator") {?>
                            <li><a class="glyphicon glyphicon-pencil"
                                   href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/posts/post_edit.php?id=<?php echo $_smarty_tpl->tpl_vars['question']->value['post_id'];?>
"
                                   data-toggle="tooltip" title="Edit"></a></li>
                            <li><a class="glyphicon glyphicon-trash"
                                   href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/post/question_delete.php?id=<?php echo $_smarty_tpl->tpl_vars['question']->value['post_id'];?>
"
                                   data-toggle="tooltip" title="Remove"></a></li>
                        <?php }?>
                    <?php }?>
                </ul>



                <?php  $_smarty_tpl->tpl_vars['comment'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['comment']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['question_comments']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['comment']->key => $_smarty_tpl->tpl_vars['comment']->value) {
$_smarty_tpl->tpl_vars['comment']->_loop = true;
?>
                    <?php echo $_smarty_tpl->getSubTemplate ('comments/comment.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                <?php } ?>


                <?php if ((isset($_smarty_tpl->tpl_vars['USERNAME']->value))) {?>
                    <?php $_smarty_tpl->tpl_vars["post_id"] = new Smarty_variable($_smarty_tpl->tpl_vars['question']->value['post_id'], null, 0);?>
                    <?php echo $_smarty_tpl->getSubTemplate ('comments/comment_form.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                <?php }?>
            </div>

        </div>



        <div class="answers">

            <?php if ((count($_smarty_tpl->tpl_vars['question_answers']->value)>0)) {?>
                <h4>Answers</h4>
            <?php } else { ?>
                <h4>No answers</h4>
            <?php }?>

            <?php  $_smarty_tpl->tpl_vars['answer'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['answer']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['question_answers']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['answer']->key => $_smarty_tpl->tpl_vars['answer']->value) {
$_smarty_tpl->tpl_vars['answer']->_loop = true;
?>
                <?php echo $_smarty_tpl->getSubTemplate ('posts/answer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php } ?>
        </div>
        <?php if ((isset($_smarty_tpl->tpl_vars['USERNAME']->value))&&$_smarty_tpl->tpl_vars['question_author']->value!=$_smarty_tpl->tpl_vars['currentUser']->value) {?>
            <?php echo $_smarty_tpl->getSubTemplate ('forms/answer_add.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

        <?php }?>
    <?php }?>
</div>


<div id="comment_edit_modal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit Comment</h4>
            </div>
            <div class="modal-body">
                <form class="comment_edit_form" action="../../actions/post/comment_edit.php" method="post">
                    <div class="form-group">
                        <input type="hidden" name="comment_id">
                        <textarea class="formgroup form-control" name="edited_text"></textarea>
                    </div>

                    <button type="submit" class="btn btn-success edit_comment_apply">Apply</button>
                </form>
            </div>
        </div>

    </div>
</div>

<div id="report_modal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Report</h4>
            </div>
            <div class="modal-body">
                <form class="report_form" action="../../actions/report/report_add.php" method="post">
                    <input type="hidden" name="post_id">
                    <div class="form-group">
                        <label for="report_type">Type:</label>
                        <select id="report_type" class="form-control" name="type" required>
                            <option value="">Choose</option>
                            <option value="DuplicateQuestion">Duplicate Question</option>
                            <option value="LackOfClarity">Lack Of Clarity</option>
                            <option value="InnapropriateLanguage">Innapropriate Language</option>
                            <option value="BadBehavior">Bad Behavior</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="report_description">Description:</label>
                        <textarea id="report_description" class="formgroup form-control" name="description" required></textarea>
                    </div>

                    <button type="submit" class="btn btn-success">Submit</button>
                </form>
            </div>
        </div>

    </div>
</div>

<script type="text/javascript">
    var username = "<?php echo $_smarty_tpl->tpl_vars['USERNAME']->value;?>
";
    var BASE_URL = "<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
";
</script>

<script type='text/javascript' src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
lib/js/report.js"></script>
<script type='text/javascript' src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
lib/js/comment.js"></script>
<script type='text/javascript' src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
lib/js/votes.js"></script>

<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
lib/js/question.js"></script><?php }} ?>
