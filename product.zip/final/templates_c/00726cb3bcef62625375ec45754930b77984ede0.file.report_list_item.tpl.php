<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:55:49
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/lists/report_list_item.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2033624819592c98e5183000-27008145%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '00726cb3bcef62625375ec45754930b77984ede0' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/lists/report_list_item.tpl',
      1 => 1496094327,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2033624819592c98e5183000-27008145',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'report' => 0,
    'BASE_URL' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c98e51df0b0_95722676',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c98e51df0b0_95722676')) {function content_592c98e51df0b0_95722676($_smarty_tpl) {?><div id="report-<?php echo $_smarty_tpl->tpl_vars['report']->value['id'];?>
" class="row">

    <div class="col-sm-10 pre">
        <div class="panel-group">
            <div class="panel panel-default">
                <div class="panel-heading" data-toggle="collapse" data-target="#collapse<?php echo $_smarty_tpl->tpl_vars['report']->value['id'];?>
">
                    <div class="row">
                        <div class="col-sm-6 col-xs-12">
                            <h4>
                               [<?php echo $_smarty_tpl->tpl_vars['report']->value['type'];?>
] #<?php echo $_smarty_tpl->tpl_vars['report']->value['id'];?>

                            </h4>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/posts/question.php?id=<?php echo $_smarty_tpl->tpl_vars['report']->value['question_id'];?>
" class="btn btn-primary btn-block no-collapse">
                                Go to question >
                            </a>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <button type="button" class="btn btn-danger btn-block no-collapse delete-report">
                                Delete
                            </button>
                        </div>
                    </div>
                </div>
                <div id="collapse<?php echo $_smarty_tpl->tpl_vars['report']->value['id'];?>
" class="panel-collapse collapse">
                    <div class="panel-body">
                        <h4>Original Post</h4>
                        <div class="well">
                            <?php echo $_smarty_tpl->tpl_vars['report']->value['post_text'];?>

                            <br>
                            <small>last modified by <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/profile/view_profile.php?id=<?php echo $_smarty_tpl->tpl_vars['report']->value['post_author_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['report']->value['post_author'];?>
</a></small>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <h4>Report</h4>
                        <div>
                            <?php echo $_smarty_tpl->tpl_vars['report']->value['description'];?>

                            <br>
                            <small>reported by <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/profile/view_profile.php?id=<?php echo $_smarty_tpl->tpl_vars['report']->value['report_author_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['report']->value['report_author'];?>
</a></small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div><?php }} ?>
