<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:55:49
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/admin/reports.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1989298034592c98e50d98c0-42347862%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '54ee0b73ab2e88b15c4656277e122d58c4f1ad55' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/admin/reports.tpl',
      1 => 1496094327,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1989298034592c98e50d98c0-42347862',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'results' => 0,
    'url' => 0,
    'page' => 0,
    'limit' => 0,
    'var' => 0,
    'BASE_URL' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c98e517bd82_54864808',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c98e517bd82_54864808')) {function content_592c98e517bd82_54864808($_smarty_tpl) {?><div class="col-md-9">

    <div class="panel panel-default">

        <div class="panel-heading">
            <div class="panel-title">
                <i class="glyphicon glyphicon-wrench pull-right"></i>
                <h4>Reports(<?php echo count($_smarty_tpl->tpl_vars['results']->value);?>
)</h4>
            </div>
        </div>

        <div class="panel-body">
            <div class="container-fluid">
                <?php  $_smarty_tpl->tpl_vars['report'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['report']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['results']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['report']->key => $_smarty_tpl->tpl_vars['report']->value) {
$_smarty_tpl->tpl_vars['report']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['report']->key;
?>
                    <?php echo $_smarty_tpl->getSubTemplate ('lists/report_list_item.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                <?php } ?>

                <ul class="pagination pagination-lg">
                    <li><a id="previousPage" href="?<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
&page=<?php echo max($_smarty_tpl->tpl_vars['page']->value-1,1);?>
" class="btn">«</a></li>
                    <?php $_smarty_tpl->tpl_vars['var'] = new Smarty_Variable;$_smarty_tpl->tpl_vars['var']->step = 1;$_smarty_tpl->tpl_vars['var']->total = (int) ceil(($_smarty_tpl->tpl_vars['var']->step > 0 ? count($_smarty_tpl->tpl_vars['results']->value)/$_smarty_tpl->tpl_vars['limit']->value+1 - (1) : 1-(count($_smarty_tpl->tpl_vars['results']->value)/$_smarty_tpl->tpl_vars['limit']->value)+1)/abs($_smarty_tpl->tpl_vars['var']->step));
if ($_smarty_tpl->tpl_vars['var']->total > 0) {
for ($_smarty_tpl->tpl_vars['var']->value = 1, $_smarty_tpl->tpl_vars['var']->iteration = 1;$_smarty_tpl->tpl_vars['var']->iteration <= $_smarty_tpl->tpl_vars['var']->total;$_smarty_tpl->tpl_vars['var']->value += $_smarty_tpl->tpl_vars['var']->step, $_smarty_tpl->tpl_vars['var']->iteration++) {
$_smarty_tpl->tpl_vars['var']->first = $_smarty_tpl->tpl_vars['var']->iteration == 1;$_smarty_tpl->tpl_vars['var']->last = $_smarty_tpl->tpl_vars['var']->iteration == $_smarty_tpl->tpl_vars['var']->total;?>
                        <li><a id="currentPage" href="?<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
&page=<?php echo $_smarty_tpl->tpl_vars['var']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['var']->value;?>
</a></li>
                    <?php }} ?>
                    <li><a id="nextPage" href="?<?php echo $_smarty_tpl->tpl_vars['url']->value;?>
&page=<?php echo min($_smarty_tpl->tpl_vars['page']->value+1,ceil($_smarty_tpl->tpl_vars['results']->value['0']['count']/$_smarty_tpl->tpl_vars['limit']->value));?>
"
                           class="btn">»</a></li>
                </ul>

                <script>
                    var numberOfPages = <?php echo ceil(count($_smarty_tpl->tpl_vars['results']->value['0'])/$_smarty_tpl->tpl_vars['limit']->value);?>
;
                    var currentPage = parseInt($("#currentPage").text());

                    $(function () {

                        if (numberOfPages === currentPage) {
                            $("#nextPage").addClass("disabled");
                        }

                        {
                            if (currentPage === 1)
                                $("#previousPage").addClass("disabled");
                        }
                    });
                </script>

            </div>

        </div>
    </div>

    <script type='text/javascript' src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
lib/js/reports_menu.js"></script>
    <hr>
</div><?php }} ?>
