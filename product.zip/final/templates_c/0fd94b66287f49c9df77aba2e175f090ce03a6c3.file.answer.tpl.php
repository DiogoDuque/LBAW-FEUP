<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:56:33
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/posts/answer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:23325411592c99118c5382-82312773%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0fd94b66287f49c9df77aba2e175f090ce03a6c3' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/posts/answer.tpl',
      1 => 1496094327,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '23325411592c99118c5382-82312773',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'answer' => 0,
    'BASE_URL' => 0,
    'currentUser' => 0,
    'USERNAME' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c99119364b7_74045260',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c99119364b7_74045260')) {function content_592c99119364b7_74045260($_smarty_tpl) {?>
<div class="answer row">
    <small class="pull-right">
        <?php echo $_smarty_tpl->tpl_vars['answer']->value['post']['up_votes'];?>

        <span class="glyphicon glyphicon-thumbs-up"></span>
        <?php echo $_smarty_tpl->tpl_vars['answer']->value['post']['down_votes'];?>

        <span class="glyphicon glyphicon-thumbs-down"></span>
    </small>

    <div class="userInfo col-md-2">

        <div class="user">
            <?php if ($_smarty_tpl->tpl_vars['answer']->value['author']['filename']) {?>
                <img alt="User Pic" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
resources/uploads/<?php echo $_smarty_tpl->tpl_vars['answer']->value['author']['filename'];?>
" class="img-circle img-responsive"
                     width="100"
                     height="100">
            <?php } else { ?>
                <img alt="User Pic" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
resources/img/user.png" class="img-circle img-responsive"
                     width="100"
                     height="100">
            <?php }?>
            <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/profile/view_profile.php?id=<?php echo $_smarty_tpl->tpl_vars['answer']->value['author']['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['answer']->value['author']['username'];?>
</a>
        </div>

        <ul class="score">
            <li><span class="glyphicon glyphicon-thumbs-up" data-post_id="<?php echo $_smarty_tpl->tpl_vars['answer']->value['post_id'];?>
" ></span></li>
            <li><p class="post_score" data-post_id="<?php echo $_smarty_tpl->tpl_vars['answer']->value['post_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['answer']->value['post']['up_votes']-$_smarty_tpl->tpl_vars['answer']->value['post']['down_votes'];?>
</p></li>
            <li><span class="glyphicon glyphicon-thumbs-down" data-post_id="<?php echo $_smarty_tpl->tpl_vars['answer']->value['post_id'];?>
" ></span></li>
        </ul>
    </div>

    <div class="col-md-10">
        <p><?php echo $_smarty_tpl->tpl_vars['answer']->value['version']['text'];?>
</p>
        <ul class="actions pull-right">
        <?php if ($_smarty_tpl->tpl_vars['currentUser']->value) {?>
            <li><a class="glyphicon glyphicon-comment comment_add_toogle" href="#" data-toggle="tooltip" title="Comment"></a></li>
            <li><a class="glyphicon glyphicon-flag report_button" href="<?php echo $_smarty_tpl->tpl_vars['answer']->value['post_id'];?>
" data-toggle="tooltip" title="Report"></a></li>
            <?php if ($_smarty_tpl->tpl_vars['currentUser']->value['username']==$_smarty_tpl->tpl_vars['answer']->value['author']['username']||$_smarty_tpl->tpl_vars['currentUser']->value['privilege_level']=="Administrator"||$_smarty_tpl->tpl_vars['currentUser']->value['privilege_level']=="Moderator") {?>
                <li><a class="glyphicon glyphicon-pencil" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/posts/post_edit.php?id=<?php echo $_smarty_tpl->tpl_vars['answer']->value['post_id'];?>
"  data-toggle="tooltip" title="Edit"></a>
                <li><a class="glyphicon glyphicon-trash answer-delete" href="#" data-toggle="tooltip" title="Remove"></a></li>
            <?php }?>
        <?php }?>
        </ul>



        <?php  $_smarty_tpl->tpl_vars['comment'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['comment']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['answer']->value['comments']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['comment']->key => $_smarty_tpl->tpl_vars['comment']->value) {
$_smarty_tpl->tpl_vars['comment']->_loop = true;
?>
            <?php echo $_smarty_tpl->getSubTemplate ('comments/comment.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

        <?php } ?>


        <?php if ((isset($_smarty_tpl->tpl_vars['USERNAME']->value))) {?>
            <?php $_smarty_tpl->tpl_vars["post_id"] = new Smarty_variable($_smarty_tpl->tpl_vars['answer']->value['post_id'], null, 0);?>
            <?php echo $_smarty_tpl->getSubTemplate ('comments/comment_form.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

        <?php }?>
    </div>

</div><?php }} ?>
