<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:56:33
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/common/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:485794135592c9911970ba7-91890553%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ddb90b382fc5d0f4c86a602ea733366b5fa904d1' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/common/footer.tpl',
      1 => 1496094327,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '485794135592c9911970ba7-91890553',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'BASE_URL' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c9911974c57_42596253',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c9911974c57_42596253')) {function content_592c9911974c57_42596253($_smarty_tpl) {?>
<footer class="container-fluid text-center">
    <div class="row">
        <div class="col-sm-3 pull-left">
            <a href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/help.php">Frequently asked questions</a>
        </div>

        <div class="col-sm-3 pull-right">
            ®LBAW1623
        </div>
    </div>
</footer>

</body>
</html><?php }} ?>
