<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:55:22
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/member/profile.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1989105469592c98ca0e7dc2-65253286%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '47cd79581d2d07abbdb9ee0209124c2c6080563d' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/member/profile.tpl',
      1 => 1496094327,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1989105469592c98ca0e7dc2-65253286',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'member' => 0,
    'BASE_URL' => 0,
    'self' => 0,
    'score' => 0,
    'lastPosts' => 0,
    'post' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c98ca1b8662_13966616',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c98ca1b8662_13966616')) {function content_592c98ca1b8662_13966616($_smarty_tpl) {?><div class="container">
    <div class="row">

        <div class="col-md-5  toppad  pull-right col-md-offset-3 ">
        </div>

        <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 col-xs-offset-0 col-sm-offset-0 col-md-offset-2 col-lg-offset-2 toppad" >

            <div class="panel panel-info">
                <div class="panel-heading">
                    <h3 class="panel-title" align="center">User Profile</h3>
                </div>

                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-4 col-lg-4 " align="center">
                            <?php if ($_smarty_tpl->tpl_vars['member']->value['filename']) {?>
                                <img alt="User Pic" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
resources/uploads/<?php echo $_smarty_tpl->tpl_vars['member']->value['filename'];?>
" class="img-circle img-responsive">
                            <?php } else { ?>
                                <img alt="User Pic" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
resources/img/user.png" class="img-circle img-responsive">
                            <?php }?>

                            <br>

                            <?php if ($_smarty_tpl->tpl_vars['self']->value) {?>
                                <form class="form-group" action="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
actions/member/update_img_action.php" method="post" enctype="multipart/form-data">
                                    <label class="btn btn-primary btn-block">
                                        <span>No file selected</span>
                                        <input id="image-upload" type="file" name="photo" style="display: none">
                                    </label>
                                    <input type="submit" value="Submit" class="btn btn-success btn-block">

                                </form>
                            <?php }?>


                        </div>
                        <div class="col-md-8 col-lg-8">
                            <table class="table table-user-information">
                                <tbody>
                                <tr>
                                    <td>Username:</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['member']->value['username'];?>
</td>
                                </tr>
                                <tr>
                                    <td>Email:</td>
                                    <td><a href="mailto:<?php echo $_smarty_tpl->tpl_vars['member']->value['email'];?>
"><?php echo $_smarty_tpl->tpl_vars['member']->value['email'];?>
</a></td>
                                </tr>
                                <tr>
                                    <td>Score:</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['score']->value['sum'];?>
</td>
                                </tr>
                                <tr>
                                    <td>Member Privilege:</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['member']->value['privilege_level'];?>
</td>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                </tr>
                                </tbody>
                            </table>

                            <?php if ($_smarty_tpl->tpl_vars['self']->value) {?>
                                <div class="edit pull-right">
                                    <a href="../../pages/profile/update_profile.php"title="Edit" data-toggle="tooltip" type="button" class="btn btn-sm btn-warning">
                                        <i class="glyphicon glyphicon-edit"></i>
                                    </a>
                                </div>
                                <div class="control-group">
                                    <label></label>
                                    <div class="controls">
                                        <button id="removeMember" type="submit" class="btn btn-danger">Remove</button>
                                    </div>
                                </div>
                            <?php }?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="title" align="center">
            <h3>Latest Topics</h3>
        </div>
    </div>
</div>

<div class="container">
    <div class="row ">
        <div class="tabela" id="opdRetro">
            <table class="table table-striped table-hover">
                <thead>
                <tr class="bg-primary">
                    <th>Question</th>
                    <th>Category</th>
                    <th>Date</th>
                </tr>
                </thead>

                <?php  $_smarty_tpl->tpl_vars['post'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['post']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['lastPosts']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['post']->key => $_smarty_tpl->tpl_vars['post']->value) {
$_smarty_tpl->tpl_vars['post']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['post']->key;
?>
                    <tr>
                        <td><a class="" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/posts/question.php?id=<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['post']->value['title'];?>
</a></td>
                        <td><a class="" href="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
pages/home.php?category=<?php echo $_smarty_tpl->tpl_vars['post']->value['category_id'];?>
"><?php echo $_smarty_tpl->tpl_vars['post']->value['category'];?>
</a></td>
                        <td><?php echo $_smarty_tpl->tpl_vars['post']->value['date'];?>
</td>
                    </tr>
                <?php } ?>
            </table>



        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
lib/js/profile.js"></script><?php }} ?>
