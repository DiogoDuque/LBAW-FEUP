<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:56:33
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/forms/answer_add.tpl" */ ?>
<?php /*%%SmartyHeaderCode:105909850592c9911967b47-95577888%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c032cf2b2974ef7bf1d3f2db5dca75a8f735970c' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/forms/answer_add.tpl',
      1 => 1496077850,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '105909850592c9911967b47-95577888',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'question_id' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c991196dfe4_66629991',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c991196dfe4_66629991')) {function content_592c991196dfe4_66629991($_smarty_tpl) {?><div class="new-answer">
    <h3>Your answer</h3>


    <form action="../../actions/post/answer_add.php" method="post">

        <input type="hidden" name="post_id" value="<?php echo $_smarty_tpl->tpl_vars['question_id']->value;?>
">


        <textarea id="summernote" class="formgroup" name="edited_text">
            </textarea>


        <script>
            $(document).ready(function () {
                var summernote = $('#summernote');
                summernote.summernote({
                    height: '20rem',
                    minHeight: '20rem',
                    toolbar: [
                        // [groupName, [list of button]]
                        ['style', ['bold', 'italic', 'underline', 'clear']],
                        ['font', ['strikethrough', 'superscript', 'subscript']],
                        ['para', ['ul', 'ol']],
                        ['insert', ['link', 'table']],
                        ['misc', ['undo', 'redo', 'help']]
                    ]
                });
            });
        </script>

        <script>
            function sendAnswerText(){
                document.forms["sampleForm"].submit();
            }
        </script>

        <button type="submit" onclick="sendAnswerText()" class="btn btn-success">Apply</button>
    </form>
</div><?php }} ?>
