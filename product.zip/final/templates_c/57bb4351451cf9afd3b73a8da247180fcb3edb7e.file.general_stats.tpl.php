<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:55:42
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/admin/general_stats.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1207100868592c98deb9bb73-42337027%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '57bb4351451cf9afd3b73a8da247180fcb3edb7e' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/admin/general_stats.tpl',
      1 => 1496077850,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1207100868592c98deb9bb73-42337027',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'totalNumberOfMembers' => 0,
    'totalNumberOfQuestions' => 0,
    'totalNumberOfAnswers' => 0,
    'totalNumberOfComments' => 0,
    'totalNumberOfVotes' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c98debb7ee0_94420084',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c98debb7ee0_94420084')) {function content_592c98debb7ee0_94420084($_smarty_tpl) {?><div class="col-md-9">
    <div id="members" class="col-md-4">

        <h3>Members</h3>

        <table class="table table-striped">
            <tbody>
            <tr>
                <th scope="row">Registered members</th>
                <td><?php echo $_smarty_tpl->tpl_vars['totalNumberOfMembers']->value;?>
</td>
            </tr>
            </tbody>
        </table>

    </div>

    <div id="questions" class="col-md-4">
        <h3>Questions</h3>

        <table class="table table-striped">
            <tbody>
            <tr>
                <th scope="row">Total number of questions</th>
                <td><?php echo $_smarty_tpl->tpl_vars['totalNumberOfQuestions']->value;?>
</td>
            </tr>
            </tbody>
        </table>

    </div>

    <div id="answers" class="col-md-4">

        <h3>Answers</h3>

        <table class="table table-striped">
            <tbody>
            <tr>
                <th scope="row">Total number of answers</th>
                <td><?php echo $_smarty_tpl->tpl_vars['totalNumberOfAnswers']->value;?>
</td>
            </tr>
            </tbody>
        </table>

    </div>

    <div id="comments" class="col-md-4">

        <h3>Comments</h3>

        <table class="table table-striped">
            <tbody>
            <tr>
                <th scope="row">Total number of comments</th>
                <td><?php echo $_smarty_tpl->tpl_vars['totalNumberOfComments']->value;?>
</td>
            </tr>
            </tbody>
        </table>

    </div>

    <div id="votes" class="col-md-4">

        <h3>Votes</h3>

        <table class="table table-striped">
            <tbody>
            <tr>
                <th scope="row">Total number of votes</th>
                <td><?php echo $_smarty_tpl->tpl_vars['totalNumberOfVotes']->value;?>
</td>
            </tr>
            </tbody>
        </table>

    </div>
</div>

<div class="row pull-right">
    *These are estimated stats
</div><?php }} ?>
