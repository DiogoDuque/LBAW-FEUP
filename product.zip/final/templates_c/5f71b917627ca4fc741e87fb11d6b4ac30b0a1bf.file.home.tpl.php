<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 22:56:27
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/lists/home.tpl" */ ?>
<?php /*%%SmartyHeaderCode:555826785592c990bacf8d2-42641488%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5f71b917627ca4fc741e87fb11d6b4ac30b0a1bf' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/lists/home.tpl',
      1 => 1496094327,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '555826785592c990bacf8d2-42641488',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'title' => 0,
    'recents' => 0,
    'populars' => 0,
    'controversials' => 0,
    'BASE_URL' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c990bb24b34_51385064',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c990bb24b34_51385064')) {function content_592c990bb24b34_51385064($_smarty_tpl) {?>
<div class="container">

    <h1><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</h1>


    <ul class="nav nav-tabs">
        <li class="active"><a data-toggle="tab" href="#recent">Recent</a></li>
        <li><a data-toggle="tab" href="#popular">Most Popular</a></li>
        <li><a data-toggle="tab" href="#controversial">Most Controversial</a></li>
    </ul>


    <div class="tab-content">

        <div id="recent" class="tab-pane fade in active">
            <?php  $_smarty_tpl->tpl_vars['question'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['question']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['recents']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['question']->key => $_smarty_tpl->tpl_vars['question']->value) {
$_smarty_tpl->tpl_vars['question']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['question']->key;
?>
                <?php echo $_smarty_tpl->getSubTemplate ('lists/question_list_item.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php } ?>
        </div>

        <hr class="main-menu-questions-divider">

        <div id="popular" class="tab-pane fade">
            <?php  $_smarty_tpl->tpl_vars['question'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['question']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['populars']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['question']->key => $_smarty_tpl->tpl_vars['question']->value) {
$_smarty_tpl->tpl_vars['question']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['question']->key;
?>
                <?php echo $_smarty_tpl->getSubTemplate ('lists/question_list_item.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php } ?>
        </div>

        <div id="controversial" class="tab-pane fade">
            <?php  $_smarty_tpl->tpl_vars['question'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['question']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['controversials']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['question']->key => $_smarty_tpl->tpl_vars['question']->value) {
$_smarty_tpl->tpl_vars['question']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['question']->key;
?>
                <?php echo $_smarty_tpl->getSubTemplate ('lists/question_list_item.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

            <?php } ?>
        </div>
    </div>
</div>

<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
lib/js/home.js"></script><?php }} ?>
