<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 19:32:40
         compiled from "/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/lists/search_results.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1387422382592c6948c9c713-31362331%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b2921484d46e14b65bea6621d52d3ba6c94c21af' => 
    array (
      0 => '/opt/lbaw/lbaw1623/public_html/LBAW-FEUP/final/templates/lists/search_results.tpl',
      1 => 1496077850,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1387422382592c6948c9c713-31362331',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'results' => 0,
    'query' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c6948cd3374_65196938',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c6948cd3374_65196938')) {function content_592c6948cd3374_65196938($_smarty_tpl) {?><h1 class="text-center fill" id="results">Results</h1>

<?php if (count($_smarty_tpl->tpl_vars['results']->value)>0) {?>

    <!--Multi Link-->
    <div class="container answer">
        <?php  $_smarty_tpl->tpl_vars['question'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['question']->_loop = false;
 $_smarty_tpl->tpl_vars['i'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['results']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['question']->key => $_smarty_tpl->tpl_vars['question']->value) {
$_smarty_tpl->tpl_vars['question']->_loop = true;
 $_smarty_tpl->tpl_vars['i']->value = $_smarty_tpl->tpl_vars['question']->key;
?>
            <?php echo $_smarty_tpl->getSubTemplate ('lists/question_list_item.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

        <?php } ?>
    </div>

    <div class="container answer text-center">
        <?php echo $_smarty_tpl->getSubTemplate ('common/pagination.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    </div>
<?php } else { ?>
    <h2 class="text-center">No questions where found when searching for "<?php echo $_smarty_tpl->tpl_vars['query']->value;?>
".<br>Sugestions:</h2>
    <h3 class="text-center">Check if there are any mistakes.<br>Try diferent keywords.<br>Create a new question.</h3>
<?php }?>


<hr class="main-menu-questions-divider">

<?php }} ?>
